import{a as t}from"../chunks/entry.P2g6xgCJ.js";export{t as start};
