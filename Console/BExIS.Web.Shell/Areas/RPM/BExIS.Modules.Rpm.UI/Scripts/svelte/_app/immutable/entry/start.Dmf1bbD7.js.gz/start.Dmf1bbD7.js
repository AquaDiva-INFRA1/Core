import{a as t}from"../chunks/entry.Ce1P80zf.js";export{t as start};
