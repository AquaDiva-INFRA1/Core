import{a as t}from"../chunks/entry.CZ6YdViW.js";export{t as start};
