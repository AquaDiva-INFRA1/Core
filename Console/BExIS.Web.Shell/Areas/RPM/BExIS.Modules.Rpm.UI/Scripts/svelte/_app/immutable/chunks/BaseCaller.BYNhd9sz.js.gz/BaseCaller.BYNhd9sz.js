import"./index.CufQnT-K.js";import{h as s}from"./eslint4b.es.C89pjaTy.js";const p=async o=>{window.open(s+o,"_self").focus()};export{p as g};
