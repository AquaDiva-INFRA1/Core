import{a as t}from"../chunks/entry.BXKISWBc.js";export{t as start};
