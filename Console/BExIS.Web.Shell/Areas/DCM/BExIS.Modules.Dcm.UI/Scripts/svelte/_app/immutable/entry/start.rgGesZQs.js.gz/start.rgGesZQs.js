import{a as t}from"../chunks/entry.m5501gps.js";export{t as start};
