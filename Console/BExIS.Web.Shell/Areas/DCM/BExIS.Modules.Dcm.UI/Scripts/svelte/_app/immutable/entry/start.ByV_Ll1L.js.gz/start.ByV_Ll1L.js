import{a as t}from"../chunks/entry.B6CwSG2B.js";export{t as start};
