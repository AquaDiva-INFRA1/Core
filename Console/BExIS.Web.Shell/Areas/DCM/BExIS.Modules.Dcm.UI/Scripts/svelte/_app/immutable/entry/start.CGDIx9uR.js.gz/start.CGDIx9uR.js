import{a as t}from"../chunks/entry.Dl2HiqHD.js";export{t as start};
