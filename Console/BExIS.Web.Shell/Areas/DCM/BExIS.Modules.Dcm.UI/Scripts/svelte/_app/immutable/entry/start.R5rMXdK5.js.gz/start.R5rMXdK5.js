import{a as t}from"../chunks/entry.DBG65q7V.js";export{t as start};
