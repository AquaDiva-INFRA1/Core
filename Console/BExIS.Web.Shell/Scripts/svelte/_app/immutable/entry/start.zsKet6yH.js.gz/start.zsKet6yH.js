import{a as t}from"../chunks/entry.BBbHeC4Y.js";export{t as start};
