import{a as t}from"../chunks/entry.n5ZUJRZI.js";export{t as start};
