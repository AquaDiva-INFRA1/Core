import{a as t}from"../chunks/entry.BG1hWmz2.js";export{t as start};
